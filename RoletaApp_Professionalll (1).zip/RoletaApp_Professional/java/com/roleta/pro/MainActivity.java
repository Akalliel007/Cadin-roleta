package com.roleta.pro;

import android.app.Activity;
import android.os.Bundle;
import android.widget.*;

public class MainActivity extends Activity {

    EditText inputNumero;
    GridLayout gridNumeros;
    LinearLayout blocoT, blocoAnalises;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputNumero = findViewById(R.id.inputNumero);
        gridNumeros = findViewById(R.id.gridNumeros);
        blocoT = findViewById(R.id.blocoT);
        blocoAnalises = findViewById(R.id.blocoAnalises);
    }
}
